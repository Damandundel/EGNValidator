﻿namespace EGNValidatorApp
{
    public interface IValidator
    {
        bool Validate(string egn);
    }
}